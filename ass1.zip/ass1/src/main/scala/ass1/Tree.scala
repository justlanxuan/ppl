package ass1

enum Tree[K, V] extends TreeInterface[K, V]:
  private case Leaf(key: K, payload: V)
  private case Node(key: K, children: List[Tree[K, V]])

  import Tree.Path

  def contains(path: Path[K]): Boolean = ???

  def get(path: Path[K]): Option[Either[List[K], V]] = ???

  def flatten: List[(Path[K], V)] = ???

  def updated(path: Path[K]): Tree[K, V] = ???

  def updated(path: Path[K], payload: V): Tree[K, V] = ???

  def display: String = ???

object Tree extends TreeComp:
  def apply[K, V](key: K): Tree[K, V] = ???

  def apply[K, V](path: Path[K]): Tree[K, V] = ???

  def apply[K, V](path: Path[K], payload: V): Tree[K, V] = ???
